﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maka2.Model
{
    class Usuario
    {
        public string UserName { set; get; }
        public string Estado { set; get; }
    }
}
