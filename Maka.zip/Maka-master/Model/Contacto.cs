﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maka2.Model
{
    public class Contacto
    {
        public string UserName { get; set; }
        public string LastMessage { get; set; }
        public int numeroMensajes { get; set; }

    }
}
