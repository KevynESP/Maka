﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Maka2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summar
    /// y>
    /// 

    public partial class App : Application

    {
        public static string UsuarioLogeado = "";
    }
}
